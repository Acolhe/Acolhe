package com.example.servletusuario;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletUsuarioBuscar", value = "/ServletUsuarioBuscar")
public class ServletUsuarioBuscar extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/webapp/usuarioID.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String strIdUsuario = request.getParameter("codUsuario");
        Usuario usuario = new Usuario();

        // Convertendo os valores para números do tipo int
        int codUsuario = Integer.parseInt(strIdUsuario);

        //Configurar o tipo de resposta como HTML
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("usuarioID.jsp");
        dispatcher.include(request, response);


        // Definindo printWriter para mostrar a saída
        PrintWriter out = response.getWriter();

        out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                "<main class=\"justify-center text-center my-[10%]\">" +
                MetodoUsuarioPrint.printSelect(usuario.buscar(codUsuario)) +
                "</main>" +
                "</body></html>");

    }
}

