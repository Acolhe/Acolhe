// Método de print

package com.example.servlettbhumor;

import java.sql.*;

public class MetodoHumorPrint {

    // Método para mostrar o resultado obtido em uma tabela HTML. Recebe como parâmetro um ResultSet
    public static String printSelect(ResultSet rs) {

        String strLista = "";

        if (rs != null) { // se não tiver erro no método
            try {
                if (rs.isBeforeFirst()) { // se tiver um registro com os parâmetros na query
                    strLista += "<div> <table border=\"4\" class=\"text-xs bg-white w-full border-solid border-4 border-[#1C1C1C] rounded-xl selection:bg-[#16D391] \">" +
                            "<theader>" +
                            "<tr>" +
                            "<th>Código de Usuário</th>" +
                            "<th>Nome</th>" +
                            "<th>Código do Humor</th>" +
                            "<th>Data de Avaliação</th>" +
                            "<th>Nível de satisfação</th>" +
                            "<th>Comentário</th>" +
                            "</tr>" +
                            "</theader>" +
                            "<tbody>";
                    while (rs.next()) {
                        strLista += ("<tr>" +
                                "<td>" + rs.getInt("CODUSUARIO") + "</td>" +
                                "<td>" + rs.getString("NMUSUARIO") + "</td>" +
                                "<td>" + rs.getInt("CODHUMOR") + "</td>" +
                                "<td>" + rs.getDate("DATAAVALIACAO") + "</td>" +
                                "<td>" + rs.getInt("NIVELSATISFACAO") + "</td>" +
                                "<td>" + rs.getString("COMENTARIO") + "</td>" +
                                "</tr>"
                        );
                    }
                    strLista += "</tbody>" + "\n</table> </div>";
                    return strLista;
                } else { // se não tiver encontrado registros
                    return "<p style=\"color: red;\">SEM REGISTROS!</p>";
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            return "<p style=\"color: red;\">ERRO!</p>";
        }

        return strLista;
    }

}
