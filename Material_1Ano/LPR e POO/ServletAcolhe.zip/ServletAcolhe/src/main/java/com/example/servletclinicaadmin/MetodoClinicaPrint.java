// Método de print
package com.example.servletclinicaadmin;

import java.sql.*;

public class MetodoClinicaPrint {

    // Método para mostrar o resultado obtido em uma tabela HTML. Recebe como parâmetro um ResultSet
    public static String printSelect(ResultSet rs) {

        String strLista = "";

        if (rs != null) { // se não tiver erro no método
            try {
                if (rs.isBeforeFirst()) { // se tiver um registro com os parâmetros na query
                    strLista += "<div> <table border=\"4\" class=\"text-[11px] bg-white w-[100px] border-solid border-4 border-[#1C1C1C] rounded-xl selection:bg-[#16D391] \">" +
                            "<theader>" +
                            "<tr>" +
                            "<th>Código da Clínica</th>" +
                            "<th>Nome</th>" +
                            "<th>E-mail</th>" +
                            "<th>Telefone</th>" +
                            "<th>Descrição</th>" +
                            "<th>Imagem</th>" +
                            "<th>Bairro</th>" +
                            "<th>Cidade</th>" +
                            "<th>Nome do estado</th>" +
                            "<th>Sigla do estado</th>" +
                            "<th>Patrocinada</th>" +
                            "<th>Nível satisfação</th>" +
                            "</tr>" +
                            "</theader>" +
                            "<tbody>";
                    while (rs.next()) {
                        strLista += ("<tr>" +
                                "<td>" + rs.getInt("CODCLINICA") + "</td>" +
                                "<td>" + rs.getString("NMCLINICA") + "</td>" +
                                "<td>" + rs.getString("EMAIL") + "</td>" +
                                "<td>" + rs.getString("TELEFONE") + "</td>" +
                                "<td>" + rs.getString("DESCRICAO") + "</td>" +
                                "<td>" + rs.getString("IMAGEM") + "</td>" +
                                "<td>" + rs.getString("BAIRRO") + "</td>" +
                                "<td>" + rs.getString("CIDADE") + "</td>" +
                                "<td>" + rs.getString("NMESTADO") + "</td>" +
                                "<td>" + rs.getString("SGESTADO") + "</td>" +
                                "<td>" + rs.getBoolean("PATROCINADA") + "</td>" +
                                "<td>" + rs.getInt("NIVELSATISFACAO") + "</td>" +
                                "</tr>"
                        );
                    }
                    strLista += "</tbody>" + "\n</table> </div>";
                    return strLista;
                } else { // se não tiver encontrado registros
                    return "<p style=\"color: red;\">SEM REGISTROS!</p>";
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            return "<p style=\"color: red;\">ERRO!</p>";
        }

        return strLista;
    }

}
