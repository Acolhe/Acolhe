//JDBC da tabela humor

package com.example.servlettbhumor;

import java.sql.*;
public class Humor{

    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    // Método para criar e manter conexão com o banco. Retorna true caso a conexão esteja certa.
    // Retorna false caso algo tenha dado errado.
    public boolean conectar() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:postgresql://dpg-ckdivrtjhfbs73bfkf60-a.oregon-postgres.render.com:5432/dbacolhe_3lv1", "acolhe_user", "kjMek6kxSSxFAQFJ6m3NQsWRqRyTh1tz");
            return true;
        } catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch (SQLException SQL) {
            SQL.printStackTrace();
        }
        return false;
    }

    // Método para desconectar com o banco.
    public void desconectar(){
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    //Método que mostra todos os itens da tabela Humor
    public ResultSet mostrar() {
        if (conectar()) {
            try {
                pstmt = conn.prepareStatement("SELECT U.nmUsuario, H.*" +
                        " FROM HUMOR H" +
                        " JOIN USUARIO U ON U.CODUSUARIO = H.CODUSUARIO");
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally {
                desconectar();
            }
        } else {
            return null;
        }
        return rs;
    }

    // Método para buscar com where. Tem como parâmetro o código do usuário.
    // Retorna null caso algum erro tenha ocorrido e o ResultSet caso não tenha dado erro.
    public ResultSet buscar (int codUsuario) {
        if (conectar()) {
            // Instanciando o objeto prepareStatement (pstmt)
            try {
                pstmt = conn.prepareStatement("SELECT U.NMUSUARIO, H.* FROM HUMOR H JOIN USUARIO U ON U.CODUSUARIO = H.CODUSUARIO  WHERE H.CODUSUARIO = " + codUsuario + " ORDER BY DATAAVALIACAO");
                // Executando o comando SQL do objeto preparedStatement e armazenando no ResultSet
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally { // Sempre vai desconectar
                desconectar();
            }
        } else {
            return null;
        }

        return rs;
    }
}