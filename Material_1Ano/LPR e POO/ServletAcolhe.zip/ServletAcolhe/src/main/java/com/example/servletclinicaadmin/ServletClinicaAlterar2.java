package com.example.servletclinicaadmin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletClinica2", value = "/ServletClinicaAlterar2")
public class ServletClinicaAlterar2 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/webapp/index.html");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String strNmClinica, strDescricao, strImagem, strBairro, strCidade, strPatrocinada, strTelefone, strEmail;
        PrintWriter out2 = response.getWriter();
        int intCodClinica = 0, intNivelSatisfacao = 3;
        Clinica clinica = new Clinica();
        if (clinica.getCodigo()!=0) {
            intCodClinica = clinica.getCodigo();
        }
        else {
            out2.println("<p style=\"color: red;\">ERRO!</p>");
        }

        //Configurar o tipo de resposta como HTML
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/clinicaAlterar2.jsp");
        dispatcher.include(request, response);

        // Pegando o nome
        strNmClinica = request.getParameter("nome");
        // Pegando a descrição
        strDescricao = request.getParameter("descricao");
        // Pegando a imagem
        strImagem = request.getParameter("imagem");
        // Pegando a cidade
        strCidade = request.getParameter("cidade");
        // Pegando o bairro
        strBairro = request.getParameter("bairro");
        // Pegando se a clínica é patrocinada
        strPatrocinada = request.getParameter("bairro");
        // Pegando o telefone
        strTelefone =  request.getParameter("telefone");
        // Pegando o email
        strEmail = request.getParameter("e-mail");
        // Pegando o nível satisfaçao
        intNivelSatisfacao = Integer.parseInt(request.getParameter("nivelSatisfacao"));

        // Se ocorreu alteração no campo de nome da clínica
        if (strNmClinica != null && !strNmClinica.equals("")) {
            if (clinica.alterar("NMCLINICA", "'"+strNmClinica.toUpperCase()+"'", intCodClinica) == 1) {
                // Alteração feita com sucesso
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: green;\">NOME DA CLÍNICA ALTERADA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else if (clinica.alterar("NMCLINICA", "'"+strNmClinica.toUpperCase()+"'", intCodClinica) == -1) {
                // Ocorreu algum erro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">ERRO AO ATUALIZAR NOME DA CLÍNICA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else {
                // Não ocorreu mudança pois não encontrou registro
                out2.println("<html><body class=\"bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                        "</main>" +
                        "</body></html>");
            }
        }

        // Se ocorreu alteração no campo de descrição
        if (strDescricao != null && !strDescricao.equals("")) {
            if (clinica.alterar("DESCRICAO", "'"+strDescricao.toUpperCase()+"'", intCodClinica) == 1) {
                // Alteração feita com sucesso
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: green;\">DESCRIÇÃO DA CLÍNICA ALTERADA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else if (clinica.alterar("DESCRICAO", "'"+strDescricao.toUpperCase()+"'", intCodClinica) == -1) {
                // Ocorreu algum erro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">ERRO AO ALTERAR DESCRIÇÃO DA CLÍNICA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else {
                // Não ocorreu mudança pois não encontrou registro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                        "</main>" +
                        "</body></html>");
            }
        }

        // Se ocorreu alteração no campo de imagem
        if (strImagem != null && !strImagem.equals("")) {
            if (clinica.alterar("IMAGEM", "'"+strImagem+"'", intCodClinica) == 1) {
                // Alteração feita com sucesso
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: green;\">IMAGEM DA CLÍNICA ALTERADA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else if (clinica.alterar("IMAGEM", "'"+strImagem+"'", intCodClinica) == -1) {
                // Ocorreu algum erro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">ERRO AO ATUALIZAR IMAGEM DA CLÍNICA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else {
                // Não ocorreu mudança pois não encontrou registro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                        "</main>" +
                        "</body></html>");
            }
        }

        // Se ocorreu alteração no campo do nome da cidade
        if (strCidade != null && !strCidade.equals("")) {
            if (clinica.alterar("CIDADE", "'"+strCidade.toUpperCase()+"'", intCodClinica) == 1) {
                // Alteração feita com sucesso
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: green;\">CIDADE DA CLÍNICA ALTERADA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else if (clinica.alterar("CIDADE", "'"+strCidade.toUpperCase()+"'", intCodClinica) == -1) {
                // Ocorreu algum erro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">ERRO AO ATUALIZAR CIDADE DA CLÍNICA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else {
                // Não ocorreu mudança pois não encontrou registro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                        "</main>" +
                        "</body></html>");
            }
        }

        // Se ocorreu alteração no campo do nome do bairro
        if (strBairro != null && !strBairro.equals("")) {
            if (clinica.alterar("BAIRRO", "'"+strBairro.toUpperCase()+"'", intCodClinica) == 1) {
                // Alteração feita com sucesso
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: green;\">BAIRRO DA CLÍNICA ALTERADA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else if (clinica.alterar("BAIRRO", "'"+strBairro.toUpperCase()+"'", intCodClinica) == -1) {
                // Ocorreu algum erro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">ERRO AO ATUALIZAR BAIRRO DA CLÍNICA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else {
                // Não ocorreu mudança pois não encontrou registro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                        "</main>" +
                        "</body></html>");
            }
        }

        // Se a clínica é patrocinada ou não
        if (strPatrocinada != null) {
            if (strPatrocinada.equalsIgnoreCase("true") || strPatrocinada.equalsIgnoreCase("false")) {
                if (clinica.alterar("PATROCINADA", Boolean.parseBoolean(strPatrocinada), intCodClinica) == 1) {
                    // Alteração feita com sucesso
                    out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                            "<main class=\"justify-center text-center my-[10%]\">" +
                            "<p style=\"color: green;\">SITUAÇÃO DA CLÍNICA ALTERADA!</p>" +
                            "</main>" +
                            "</body></html>");
                } else if (clinica.alterar("PATROCINADA", Boolean.parseBoolean(strPatrocinada), intCodClinica) == -1) {
                    // Ocorreu algum erro
                    out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                            "<main class=\"justify-center text-center my-[10%]\">" +
                            "<p style=\"color: red;\">ERRO AO ATUALIZAR SITUAÇÃO DA CLÍNICA!</p>" +
                            "</main>" +
                            "</body></html>");
                } else {
                    // Não ocorreu mudança pois não encontrou registro
                    out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                            "<main class=\"justify-center text-center my-[10%]\">" +
                            "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                            "</main>" +
                            "</body></html>");
                }
            }
        }

        // Se ocorreu alteração no campo de telefone
        if (strTelefone != null && !strTelefone.equals("")) {
            if (clinica.alterar("TELEFONE", "'"+strTelefone+"'", intCodClinica) == 1) {
                // Alteração feita com sucesso
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: green;\">TELEFONE DA CLÍNICA ALTERADA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else if (clinica.alterar("TELEFONE", "'"+strTelefone+"'", intCodClinica) == -1) {
                // Ocorreu algum erro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">ERRO AO ATUALIZAR TELEFONE DA CLÍNICA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else {
                // Não ocorreu mudança pois não encontrou registro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                        "</main>" +
                        "</body></html>");
            }
        }

        // Se ocorreu alteração no campo de e-mail
        if (strEmail != null && !strEmail.equals("")) {
            if (clinica.alterar("EMAIL", "'"+strEmail+"'", intCodClinica) == 1) {
                // Alteração feita com sucesso
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: green;\">E-MAIL DA CLÍNICA ALTERADA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else if (clinica.alterar("EMAIL", "'"+strEmail+"'", intCodClinica) == -1) {
                // Ocorreu algum erro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">ERRO AO ATUALIZAR E-MAIL DA CLÍNICA!</p>" +
                        "</main>" +
                        "</body></html>");
            } else {
                // Não ocorreu mudança pois não encontrou registro
                out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                        "<main class=\"justify-center text-center my-[10%]\">" +
                        "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                        "</main>" +
                        "</body></html>");
            }
        }

        // Se ocorreu alteração no campo de nivelSatisfacao
        // Se a clínica é patrocinada ou não
        if (intNivelSatisfacao != 0) {
            if (intNivelSatisfacao == 1 || intNivelSatisfacao == 2 || intNivelSatisfacao == 3 || intNivelSatisfacao == 4 || intNivelSatisfacao == 5) {
                if (clinica.alterar("NIVELSATISFACAO", intNivelSatisfacao, intCodClinica) == 1) {
                    // Alteração feita com sucesso
                    out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                            "<main class=\"justify-center text-center my-[10%]\">" +
                            "<p style=\"color: green;\">NIVEL SATISFACAO DA CLÍNICA ALTERADA!</p>" +
                            "</main>" +
                            "</body></html>");
                } else if (clinica.alterar("NIVELSATISFACAO", intNivelSatisfacao, intCodClinica) == -1) {
                    // Ocorreu algum erro
                    out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                            "<main class=\"justify-center text-center my-[10%]\">" +
                            "<p style=\"color: red;\">ERRO AO ATUALIZAR NIVEL SATISFACAO DA CLÍNICA!</p>" +
                            "</main>" +
                            "</body></html>");
                } else {
                    // Não ocorreu mudança pois não encontrou registro
                    out2.println("<html><body class=\"margin 0 bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[]\">" +
                            "<main class=\"justify-center text-center my-[10%]\">" +
                            "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                            "</main>" +
                            "</body></html>");
                }
            }
        }
    }


}
