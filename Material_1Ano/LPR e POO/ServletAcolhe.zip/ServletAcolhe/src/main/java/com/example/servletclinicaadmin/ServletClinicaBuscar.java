package com.example.servletclinicaadmin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletClinica", value = "/ServletClinicaBuscar")
public class ServletClinicaBuscar extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/webapp/index.html");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // Pegando
        String strCampo = request.getParameter("campo");
        String strValor = request.getParameter("valor");
        Clinica clinica = new Clinica();
        PrintWriter out = response.getWriter();

        //Configurar o tipo de resposta como HTML
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/clinicaBuscar.jsp");
        dispatcher.include(request, response);

        if (strCampo.equalsIgnoreCase("codClinica")) {
            // Converter o valor para número inteiro
            int codClinica = Integer.parseInt(strValor);
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    MetodoClinicaPrint.printSelect(clinica.buscarCodigo(codClinica)) +
                    "</main>" +
                    "</body></html>");
        } else {
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    MetodoClinicaPrint.printSelect(clinica.buscar(strCampo, strValor)) +
                    "</main>" +
                    "</body></html>");
        }


    }
}
