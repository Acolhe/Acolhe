//JDBC da tabela clínica

package com.example.servletclinicaadmin;

import java.sql.*;
import java.util.Locale;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

public class Clinica{

    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    // Método para criar e manter conexão com o banco. Retorna true caso a conexão esteja certa.
    // Retorna false caso algo tenha dado errado.
    public boolean conectar() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:postgresql://dpg-ckdivrtjhfbs73bfkf60-a.oregon-postgres.render.com:5432/dbacolhe_3lv1", "acolhe_user", "kjMek6kxSSxFAQFJ6m3NQsWRqRyTh1tz");
            return true;
        } catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch (SQLException SQL) {
            SQL.printStackTrace();
        }
        return false;
    }

    // Método para desconectar com o banco.
    public void desconectar(){
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    //Método que mostra todos os itens da tabela Clínica
    public ResultSet mostrar() {
        if (conectar()) {
            try {
                pstmt = conn.prepareStatement("SELECT * FROM CLINICA ORDER BY CODCLINICA");
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally {
                desconectar();
            }
        } else {
            return null;
        }
        return rs;
    }

    // Métodos para buscar com where.
    // Retornam null caso algum erro tenha ocorrido e o ResultSet caso não tenha dado erro.

    // Método buscar por código da clínica. Tem como parâmetro o código que deverá ser buscado.
    public ResultSet buscarCodigo (int codClinica) {
        if (conectar()) {
            // Instanciando o objeto prepareStatement (pstmt)
            try {
                pstmt = conn.prepareStatement("SELECT * FROM CLINICA WHERE CODCLINICA = " + codClinica);
                // Executando o comando SQL do objeto preparedStatement e armazenando no ResultSet
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally { // Sempre vai desconectar
                desconectar();
            }
        } else {
            return null;
        }

        return rs;
    }

    // Método buscar por estado/nome. Tem como parâmetro o campo que será colocado no WHERE e o valor que será buscado>
    public ResultSet buscar (String strCampo, String strValor) {
        if (conectar()) {
            // Instanciando o objeto prepareStatement (pstmt)
            try {
                pstmt = conn.prepareStatement("SELECT * FROM CLINICA WHERE " + strCampo + " = '" + strValor + "'");
                // Executando o comando SQL do objeto preparedStatement e armazenando no ResultSet
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally { // Sempre vai desconectar
                desconectar();
            }
        } else {
            return null;
        }

        return rs;
    }


    // Método para alterar uma clínica. Você passa como parâmetro o nome do campo que deve
    // ser alterado, o novo valor e o código da clínica que será alterada
    // Retorna 1 caso a alteração tenha sido feita. -1 caso tenha ocorrido algum erro e 0 caso nenhuma linha tenha sido alterada.
    public int alterar(String strCampo, Object objNovoValor, int codClinica) {
        if (conectar()) {
            try {
                String update = "UPDATE CLINICA SET " + strCampo + " = " + objNovoValor + " WHERE CODCLINICA = " + codClinica;
                pstmt = conn.prepareStatement(update);

                if (pstmt.executeUpdate() == 0) {
                    return 0;
                }

                return 1;

            } catch (SQLException e) {
                e.printStackTrace();
                return -1;
            } finally {
                desconectar();
            }
        } else {
            return -1;
        }
    }

    // Método para remover. Tem como parâmetro o código da clínica que será removida.
    // Retorna 1 caso a alteração tenha sido feita. -1 caso tenha ocorrido algum erro e 0 caso nenhuma linha tenha sido alterada.
    public int remover(int codClinica) {
        if (conectar()) {

            try {
                pstmt = conn.prepareStatement("DELETE FROM CLINICA WHERE CODCLINICA = ?");
                pstmt.setInt(1, codClinica);
                // Instanciando objeto preparedStatement

                if (pstmt.executeUpdate() == 0) {
                    return 0;
                }

                return 1; // retorna 1 caso a remoção tenha acontecido

            } catch (SQLException e) {
                e.printStackTrace();
                return -1; // retorna -1 caso tenha ocorrido algum erro
            } finally {
                desconectar();
            }
        } else {
            return -1;
        }
    }

    // Cria uma view com o código da clínica que o usuário deseja alterar.
    // Esse código é recebido pela clinicaAlterar.jsp
    // Recebe como parâmetro o código inserido
    public void setCodigo(int codigo) {
        if (conectar()) {
            try {
                pstmt = conn.prepareStatement("CREATE OR REPLACE VIEW escolha AS (SELECT " + codigo + " AS codigo);");
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
            } finally {
                desconectar();
            }
        }
    }


    // Método que retorna o código da clínica que está armazenado na view ESCOLHA criada no método
    // setCodigo.
    // Caso tenha dado algum erro retorna 0.
    public int getCodigo() {
        int codigo = 0;
        if (conectar()) {
            try {
                pstmt = conn.prepareStatement("SELECT codigo" +
                        " FROM escolha" +
                        " LIMIT 1");
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return 0;
            } finally {
                desconectar();
            }
        } else {
            return 0;
        }
        if (rs != null) { // se não tiver erro no método
            try {
                if (rs.isBeforeFirst()) { // se tiver um registro com os parâmetros na query
                    while (rs.next()) {
                        codigo = rs.getInt("codigo");
                    }
                } else { // se não tiver encontrado registros
                    return 0;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            return 0;
        }

        return codigo;
    }
}