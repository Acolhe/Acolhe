package com.example.servletclinicaadmin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletClinicaRemover", value = "/ServletClinicaRemover")
public class ServletClinicaRemover extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/webapp/index.html");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Configurar o tipo de resposta como HTML
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/clinicaRemover.jsp");
        dispatcher.include(request, response);

        // Pegando parâmetros
        String strCodClinica = request.getParameter("codClinica");
        Clinica clinica = new Clinica();

        // Converteer o código da clínica
        int intCodClinica = Integer.parseInt(strCodClinica);

        // Chamar o método para mostrar
        PrintWriter out = response.getWriter();
        if (clinica.remover(intCodClinica) == 1) {
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    "<p style=\"color: green;\">CLÍNICA REMOVIDA!</p>" +
                    "</main>" +
                    "</body></html>");
        } else if (clinica.remover(intCodClinica) == -1){
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    "<p style=\"color: red;\">ERRO!</p>" +
                    "</main>" +
                    "</body></html>");
        } else {
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                    "</main>" +
                    "</body></html>");
        }

    }
}
