package com.example.servletusuario;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "UsuarioServlet", value = "/UsuarioServlet")
public class ServletUsuarioRemover extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/webapp/index.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/deletarUsuario.jsp");
        dispatcher.include(request, response);

        // Conversão para int
        int intUsuarioId = Integer.parseInt(request.getParameter("usuario")); // id do forms

        Usuario conexao = new Usuario();

        // Chamar o método para mostrar
        PrintWriter out = response.getWriter();

        int removido = conexao.remover(intUsuarioId);

        if (removido == 1) {
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    "<p style=\"color: green;\">USUÁRIO REMOVIDO!</p>" +
                    "</main>" +
                    "</body></html>");
        } else if (removido == -1){
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    "<p style=\"color: red;\">ERRO!</p>" +
                    "</main>" +
                    "</body></html>");
        } else {
            out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] selection:bg-[#16D391] \">" +
                    "<main class=\"justify-center text-center my-[10%]\">" +
                    "<p style=\"color: red;\">SEM REGISTROS!</p>" +
                    "</main>" +
                    "</body></html>");
        }

    }


}
