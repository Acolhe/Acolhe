//JDBC da tabela usuário

package com.example.servletusuario;

import java.sql.*;

public class Usuario {

    private Connection conn;
    private PreparedStatement pstmt;
    private ResultSet rs;

    // Método para criar e manter conexão com o banco. Retorna true caso a conexão esteja certa.
    // Retorna false caso algo tenha dado errado.
    public boolean conectar() {
        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:postgresql://dpg-ckdivrtjhfbs73bfkf60-a.oregon-postgres.render.com/dbacolhe_3lv1", "acolhe_user", "kjMek6kxSSxFAQFJ6m3NQsWRqRyTh1tz");
            return true;
        } catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        } catch (SQLException SQL) {
            SQL.printStackTrace();
        }
        return false;
    }

    // Método para desconectar com o banco.
    public void desconectar(){
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    //Método que mostra todos os itens da tabela Usuario
    public  ResultSet mostrar() {
        if (conectar()) {
            try {
                pstmt = conn.prepareStatement("SELECT * FROM USUARIO");
                rs = pstmt.executeQuery();

            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally {
                desconectar();
            }
        } else {
            return null;
        }
        return rs;
    }

    // Método para remover. Tem como parâmetro o código da clínica que será removida.
    // Retorna 1 caso a alteração tenha sido feita. -1 caso tenha ocorrido algum erro e 0 caso nenhuma linha tenha sido alterada.
    public int remover(int intUsuarioId) {
        if (conectar()) {
            try {
                // Deletar o usuario da tabela Usuario
                pstmt = conn.prepareStatement("DELETE FROM USUARIO WHERE CODUSUARIO = ?");
                pstmt.setInt(1, intUsuarioId);

                // Instanciando objeto preparedStatement
                if (pstmt.executeUpdate() == 0) {
                    return 0;
                }
                // retorna 1 caso a remoção tenha acontecido
                return 1;
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println(e.getErrorCode());
                return -1; // retorna -1 caso tenha ocorrido algum erro
            } finally {
                desconectar();
            }
        } else {
            return -1;
        }
    }


    // Método buscar por código do usuário. Tem como parâmetro o código do usuário.
    public ResultSet buscar (int codUsuario) {
        if (conectar()) {
            // Instanciando o objeto prepareStatement (pstmt)
            try {
                pstmt = conn.prepareStatement("SELECT * FROM USUARIO WHERE CODUSUARIO = " + codUsuario);
                // Executando o comando SQL do objeto preparedStatement e armazenando no ResultSet
                rs = pstmt.executeQuery();
            } catch (SQLException SQL) {
                SQL.printStackTrace();
                return null;
            } finally { // Sempre vai desconectar
                desconectar();
            }
        } else {
            return null;
        }

        return rs;
    }


}


