package com.example.servletclinicaadmin;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletClinicaAlterar", value = "/ServletClinicaAlterar")
public class ServletClinicaAlterar extends HttpServlet {
    String StrIdClinica;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/webapp/index.html");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Configurar o tipo de resposta como HTML
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/clinicaAlterar.jsp");
        dispatcher.include(request, response);
        Clinica clinica = new Clinica();
        String strIdClinica = request.getParameter("codClinica");
        int intCodClinica = Integer.parseInt(strIdClinica);
        clinica.setCodigo(intCodClinica);

        //Configurar o tipo de resposta como HTML
        response.setContentType("text/html");


        dispatcher = request.getRequestDispatcher("/clinicaAlterar2.jsp");
        dispatcher.forward(request, response);
    }
    public String getIdClinica(){
        return StrIdClinica;
    }
}
