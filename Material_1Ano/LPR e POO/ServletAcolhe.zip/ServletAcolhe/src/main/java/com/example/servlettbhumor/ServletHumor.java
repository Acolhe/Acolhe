package com.example.servlettbhumor;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ServletHumor", value = "/ServletHumor")
public class ServletHumor extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/webapp/index.html");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String StrIdUsuario = request.getParameter("codUsuario");
        Humor humor = new Humor();

        // Converteer os valores para números do tipo int
        int codUsuario = Integer.parseInt(StrIdUsuario);

        //Configurar o tipo de resposta como HTML
        response.setContentType("text/html");
        RequestDispatcher dispatcher = request.getRequestDispatcher("/humorID.jsp");
        dispatcher.include(request, response);

        // Chamar o método para mostrar
        PrintWriter out = response.getWriter();
        out.println("<html><body class=\" bg-[#C1FFE1] text-2xl relative text-[#1C1C1C] \">" +
                "<main class=\"justify-center text-center my-[10%]\">" +
                MetodoHumorPrint.printSelect(humor.buscar(codUsuario)) +
                "</main>" +
                "</body></html>");
    }
}
