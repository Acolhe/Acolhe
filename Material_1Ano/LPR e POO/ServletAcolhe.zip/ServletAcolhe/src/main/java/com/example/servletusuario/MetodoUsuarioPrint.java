// Método de print

package com.example.servletusuario;

import java.sql.*;
public class MetodoUsuarioPrint {

    // Método para mostrar o resultado obtido em uma tabela HTML. Recebe como parâmetro um ResultSet
    public static String printSelect(ResultSet rs) {

        String strLista = "";

        if (rs != null) { // se não tiver erro no método
            try {
                if (rs.isBeforeFirst()) { // se tiver um registro com os parâmetros na query
                    strLista += "<div> <table border=\"4\" class=\"text-xs bg-white w-full border-solid border-4 border-[#1C1C1C] rounded-xl selection:bg-[#16D391] \">" +
                            "<theader>" +
                            "<tr>" +
                            "<th>Código de Usuário</th>" +
                            "<th>Nome</th>" +
                            "<th>Saldo</th>" +
                            "<th>Dias consecutivos</th>" +
                            "<th>E-mail</th>" +
                            "<th>Cod Skin Principal</th>" +
                            "<th>Data Último Acesso</th>" +
                            "<th>Data Último Login</th>" +
                            "<th>Data Cadastro</th>" +
                            "<th>Premium</th>" +
                            "</tr>" +
                            "</theader>" +
                            "<tbody>";
                    while (rs.next()) {
                        strLista += ("<tr>" +
                                "<td>" + rs.getInt("CODUSUARIO") + "</td>" +
                                "<td>" + rs.getString("NMUSUARIO") + "</td>" +
                                "<td>" + rs.getInt("SALDO") + "</td>" +
                                "<td>" + rs.getInt("DIASCONSECUTIVOS") + "</td>" +
                                "<td>" + rs.getString("EMAIL") + "</td>" +
                                "<td>" + rs.getString("CODSKINPRINCIPAL") + "</td>" +
                                "<td>" + rs.getDate("DATAULTIMOACESSO") + "</td>" +
                                "<td>" + rs.getTimestamp("DATAULTIMOLOGIN") + "</td>" +
                                "<td>" + rs.getDate("DATACADASTRO") + "</td>" +
                                "<td>" + rs.getBoolean("PREMIUM") + "</td>" +
                                "</tr>"
                        );
                    }
                    strLista += "</tbody>" + "\n</table> </div>";
                    return strLista;
                } else { // se não tiver encontrado registros
                    return "<p style=\"color: red;\">SEM REGISTROS!</p>";
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            return "<p style=\"color: red;\">ERRO!</p>";
        }

        return strLista;
    }
}
