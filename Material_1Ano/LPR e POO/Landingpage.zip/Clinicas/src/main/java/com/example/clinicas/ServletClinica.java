package com.example.clinicas;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

@WebServlet(name = "ServletClinica", value = "/ServletClinica")
public class ServletClinica extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        ConexaoClinica conexao = new ConexaoClinica();
        Clinica clinica = null;
        Scanner input = new Scanner(System.in);
        ResultSet rs;
        int intCodClinica = 1;
        String strNmClinica, strDescricao, strImagem, strBairro, strCidade = "", strNmEstado = "", strSgEstado = "", strTelefone = "", strEmail = "";
        boolean boolPatrocinada;
        RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
        dispatcher.include(request, response);
        // Pegando o nome
        strNmClinica = request.getParameter("nome").toUpperCase();
        // Pegando a descrição
        strDescricao = request.getParameter("descricao").toUpperCase();
        // Pegando a imagem
        strImagem = request.getParameter("imagem");
        // Colocando o estado
        strNmEstado = request.getParameter("estado");
        strSgEstado = "SP";
        // Pegando a cidade
        strCidade = request.getParameter("cidade").toUpperCase();
        // Pegando o bairro
        strBairro = request.getParameter("bairro").toUpperCase();
        // Pegando se a clínica é patrocinada
        boolPatrocinada = false;
        // Pegando o telefone
        strTelefone =  request.getParameter("telefone");
        // Pegando o email
        strEmail = request.getParameter("e-mail");
        // Pegando a próxima sequência
        rs = conexao.codClinica();
        if (rs != null) { // não teve erro no método
            try {
                if (rs.isBeforeFirst()) { // se teve algum resultado
                    if (rs.next()) { // se tiver uma próxima linha
                        intCodClinica = rs.getInt("codClinica");
                    } // se tem alguma próxima linha para pegar a sequência

                }
                // Objeto de Clinica
                clinica = new Clinica(intCodClinica, strNmClinica.toUpperCase(), strDescricao.toUpperCase(), strImagem, strBairro.toUpperCase(), strCidade, strNmEstado, strSgEstado, boolPatrocinada, strTelefone, strEmail);

                // Colocando na função
                if (conexao.inserir(intCodClinica, clinica)) {
                    RequestDispatcher r = request.getRequestDispatcher("/inserida.jsp");
                    r.forward(request, response);
                } else { // Ocorreu erro ao inserir
                    RequestDispatcher r = request.getRequestDispatcher("/erro.jsp");
                    r.forward(request, response);
                }
            } catch (SQLException e) { // se ao pegar a próxima sequência ocorrer um erro
                e.printStackTrace();
                dispatcher = request.getRequestDispatcher("/erro.jsp");
                dispatcher.include(request, response);
            }
        } else { // se ao pegar a próxima sequência tiver erro
            dispatcher = request.getRequestDispatcher("/erro.jsp");
            dispatcher.include(request, response);
        }
    }
}
